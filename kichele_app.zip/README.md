# Kichele Lending App

Run backend on port 4000 and frontend on port 3000.
